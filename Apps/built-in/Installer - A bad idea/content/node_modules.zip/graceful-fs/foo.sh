#!/bin/bash

# set -e
false
echo 'ok'
